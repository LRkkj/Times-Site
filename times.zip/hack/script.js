let currentAudio = null;

function showPreview(videoSrc, audioSrc) {
    const preview = document.getElementById('preview');
    const video = document.getElementById('preview-video');

    // Configurar vídeo
    video.src = videoSrc;
    video.load();
    video.play();
    preview.style.display = 'block';

    // Parar áudio anterior se tiver
    if (currentAudio) {
        currentAudio.pause();
        currentAudio.currentTime = 0;
    }

    // Tocar novo áudio
    currentAudio = new Audio(audioSrc);
    currentAudio.volume = 0.5;  // Ajusta volume conforme quiser
    currentAudio.play();
}

function hidePreview() {
    const preview = document.getElementById('preview');
    const video = document.getElementById('preview-video');
    video.pause();
    video.currentTime = 0;
    preview.style.display = 'none';

    if (currentAudio) {
        currentAudio.pause();
        currentAudio.currentTime = 0;
        currentAudio = null;
    }
}

function openSpotify(link) {
    const iframe = document.getElementById('spotify-iframe');
    iframe.src = link;
    document.getElementById('spotify-player').style.display = 'flex';
}

function closeSpotify() {
    document.getElementById('spotify-player').style.display = 'none';
    document.getElementById('spotify-iframe').src = '';
}
